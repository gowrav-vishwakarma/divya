<?php

class page_index extends Page {
    function init(){
        parent::init();
        $dist=$this->add('Model_Distributor');
        $dist->addCondition('page_alias',$_GET['alias']);
        $dist->tryLoadAny();
		$dv=$this->add("View",null,null,array('view/webpage'));       
		$dv->setModel($dist);
    }
}
