<?php
class Model_CurrentDistributor extends Model_Distributor{
	function init(){
		parent::init();
		$this->addCondition('id',$this->api->auth->model->id);

		$this->addExpression('my_points')->set('
			(
				closing_age * (TotalDirectSales/1000) * ((ClosingDirectSales+1000)/1000) * (closing_agents_in_down+1) * ((TotalSelfRepurchase+1000)/1000)
				)
			');

		$this->tryLoadAny();
	}
}