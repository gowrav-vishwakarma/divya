<?php
class Model_SponsoredDistributors extends Model_Distributor {}