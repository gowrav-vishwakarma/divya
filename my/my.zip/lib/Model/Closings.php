<?php 
class Model_Closings extends Model_Table{
		var $table="jos_xclosing";
		function init(){
			parent::init();

			$this->hasOne('Distributor','distributor_id');

			$this->addField('name');
			$this->addField('DirectIncome');
			$this->addField('AgentIncome');
			$this->addField('RoyaltyIncome');
			$this->addField('LastCarryAmount');
			$this->addField('TotalAmount');
			$this->addField('TDS');
			$this->addField('AdminCharge');
			$this->addField('NetAmount');
			$this->addField('CarryAmount');

		}
}