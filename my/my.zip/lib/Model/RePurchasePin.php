<?php

class Model_RePurchasePin extends Model_PinAll {
	function init(){
		parent::init();
		$this->addCondition('For','Repurchase');
	}
}