<?php
class Model_Distributor extends Model_Table{

	var $table="jos_xtreedetails";

	function init(){
		parent::init();

		$this->hasOne('Distributor','sponsor_id')->mandatory("Sponsor Id is must");
		$this->hasOne('Distributor','introducer_id')->mandatory("Introducer Id is must");
		$this->hasOne('Pin','pin_id');

		$this->hasMany('SponsoredDistributors','sponsor_id');
		$this->hasMany('Closings','distributor_id');
		$this->hasMany('IntroducedDistributors','introducer_id');
		$this->hasMany('Page','distributor_id');

		$details = $this->join('jos_xpersonaldetails.distributor_id');

        $details->addField('fullname')->mandatory("Name is must to give");
        $details->addField('address')->type('text');
        $details->addField('mobile_no');
        $details->addField('page_alias')->mandatory('You must give a name to your page');
        $details->addField('fathers_name')->mandatory('You must give a fathername to your page');
        $details->addField('pan_no');
        $details->addField('bank_name')->mandatory('You must give a bank name to your page');
        $details->addField('bank_branch')->mandatory('You must give a bank branch to your page');
        $details->addField('bank_account_no')->mandatory('You must give a bank account number to your page');
        $details->addField('bank_IFSC')->mandatory('You must give a bank IFSC to your page');

        // $details->addField('username')->mandatory("Username is must to give");
        $details->addField('password')->display('password')->mandatory("Password is must to give");


		$this->addField('members_in_down');
		$this->addField('is_agent')->type('boolean')->defaultValue(false);
		$this->addField('is_grouphead')->type('boolean')->defaultValue(false)->system(true);
		$this->addField('is_panvarified')->type('boolean')->defaultValue(false)->system(true);


		$this->addField('joining_date')->type('date')->defaultValue(date('Y-m-d'));
		$this->addField('agent_date')->type('date')->defaultValue(null);
		$this->addField('closing_agents_in_down')->defaultValue(0);
		$this->addField('total_agents_in_down')->defaultValue(0)	;
		$this->addField('is_royalty_taken')->type('boolean')->defaultValue(false)->system(true);
		$this->addField('LegA')->defaultValue(0);
		$this->addField('LegB')->defaultValue(0);
		$this->addField('LegC')->defaultValue(0);
		$this->addField('LegD')->defaultValue(0);
		$this->addField('Path')->system(true);
		$this->addField('group_no')->system(true);
		$this->addField('ClosingDirectIncome')->defaultValue(0)->system(true);
		$this->addField('AgentIncome')->defaultValue(0)->system(true);
		$this->addField('RoyaltyIncome')->defaultValue(0)->system(true);
		$this->addField('LastCarryAmount')->defaultValue(0)->system(true);
		$this->addField('TotalAmount')->defaultValue(0)->system(true);
		$this->addField('TDS')->defaultValue(0)->system(true);
		$this->addField('AdminCharge')->defaultValue(0)->system(true);
		$this->addField('NetAmount')->defaultValue(0)->system(true);
		$this->addField('CarryAmount')->defaultValue(0)->system(true);

		$this->addField('closing_age')->defaultValue(1)->system(true);
		$this->addField('ClosingSelfRepurchase')->defaultValue(0)->system(true);
		$this->addField('TotalSelfRepurchase')->defaultValue(0)->system(true);
		$this->addField('ClosingRepurchaseInDown')->defaultValue(0)->system(true);
		$this->addField('UsedRepurchase')->defaultValue(0)->system(true);
		$this->addField('TotalDirectSales')->defaultValue(0)->system(true);
		$this->addField('ClosingDirectSales')->defaultValue(0)->system(true);


		$this->addExpression('name')->set($this->dsql()->expr('concat(distributor_id," :: ", fullname)'));
		$this->addExpression('inLeg')->set('RIGHT(Path,1)');

		$this->addExpression('role')->set('IF(is_agent=1,"Agent","Member")');

		$this->addHook('beforeSave',$this);
		$this->addHook('afterSave',$this);
	}

	function beforeSave(){
		if(!$this->loaded()){ //INSERTING NEW
			$sponsor=$this->add('Model_Distributor');
			$sponsor->load($this['sponsor_id']);
			$newPath = $sponsor['Path']. $this->recall('leg');
			$this['Path']=$newPath;
			$this['group_no']=$sponsor['group_no'];
			$this['pin_id']=$this->recall('pin_id');

			$this['is_panvarified'] = (strlen($this['pan_no'])==10)? true : false;

			$this->memorize('inserted',true);
		}else{
			// UPDATING MY PAGE
			$this['is_panvarified'] = (strlen($this['pan_no'])==10)? true : false;
		}	



	}

	function afterSave(){
		if($this->recall('inserted',false)){
			$sponsor=$this->add('Model_Distributor');
			$sponsor->load($this['sponsor_id']);

			$sponsor['Leg'.$this->recall('leg')] = $this->id;

			$sponsor['members_in_down'] = $sponsor['members_in_down']+1;
			if($sponsor['members_in_down'] == 4) {
				$sponsor['is_agent'] = true;
				$sponsor->updateAnsesstorsAgentCount();
			}

			$sponsor->saveAndUnload();

			$introducer= $this->add('Model_Distributor');
			$introducer->load($this['introducer_id']);
			$introducer['ClosingDirectSales']=$introducer['ClosingDirectSales']+ JOINING_AMOUNT;
			$introducer['TotalDirectSales']=$introducer['TotalDirectSales']+ JOINING_AMOUNT;
			$introducer['ClosingDirectIncome']=$introducer['ClosingDirectIncome']+ (JOINING_AMOUNT * DIRECT_SALES_PERCENTAGE /100.00);
			$introducer->saveAndUnload();

			$page=$this->add('Model_Page');
			$page['distributor_id']=$this->id;
			$page['alias']=$this['page_alias'];
			$page->saveAndUnload();


			$this->forget('inserted');
		}
	}

	function updateAnsesstorsAgentCount(){
		$myPath=$this['Path'];

		$q="
			UPDATE
				jos_xtreedetails
			SET
				closing_agents_in_down = closing_agents_in_down + 1,
				total_agents_in_down = total_agents_in_down + 1
    		Where 
    			Path=LEFT('$myPath',LENGTH(Path)) AND
    			is_agent = 1 AND
    			group_no = " . $this['group_no'] ;

		$this->api->db->dsql()->expr($q)->execute();

	}

	function updateRepurchaseInAnsesstors(){
		$myPath=$this['Path'];

		$q="
			UPDATE
				jos_xtreedetails
			SET
				ClosingRepurchaseInDown = ClosingRepurchaseInDown + ". JOINING_AMOUNT ."
    		Where 
    			Path=LEFT('$myPath',LENGTH(Path)) AND
    			is_agent = 1 AND
				group_no = " . $this['group_no'] ;

		$this->api->db->dsql()->expr($q)->execute();

	}

}