<?php
class Model_IntroducedDistributors extends Model_Distributor {}