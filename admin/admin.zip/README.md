pos
===

username : pos_3_admin 
password : admin

also pos_1_admin and pos_2_admin is there with password admin
A Point Of Sales system
Used as Sub system in a project. but can be developed at its own too ..
