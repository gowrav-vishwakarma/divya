<?php

// Relative path to your ATK directory
$config['atk']['base_path']='../../atk4/';
$config['dsn']='mysql://root:root@localhost/examples';

$config['url_postfix']='';
$config['url_prefix']='?page=';
$config['auth']['salt']='secret';
