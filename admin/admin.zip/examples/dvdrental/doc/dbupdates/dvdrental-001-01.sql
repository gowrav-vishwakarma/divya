alter table customer add email varchar(255);
alter table customer add password varchar(255);
