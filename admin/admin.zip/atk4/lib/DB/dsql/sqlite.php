<?php
class DB_dsql_sqlite extends DB_dsql {
}
