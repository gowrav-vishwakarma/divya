<?php
class Exception_Hook extends BaseException {
    public $return_value;
}
