<?php
/**
 * Raised when entity is not found in DB
 * @author Camper (camper@agiletech.ie) on 20.11.2009
 */
class Exception_NotFound extends Exception_InitError{}
