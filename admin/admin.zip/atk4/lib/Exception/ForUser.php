<?php
/**
 * 
 * @author Camper (camper@agiletech.ie) on 22.03.2010
 */
class Exception_ForUser extends Exception_InitError{
	
}
