$(function(){
	$('.atk-row>*:first-child:not([class*="offset"]), .atk-row>form>*:first-child[class*="span"], .atk-row>form>*[class*="span"]>*:first-child[class*="span"]').css({"margin-left":0});
	
	
	$('.atk-form fieldset .atk-form-row > .atk-form-field input[type="text"]:not([class*="span"]), .atk-form fieldset .atk-form-row > .atk-form-field input[type="password"]:not([class*="span"]), .atk-form fieldset .atk-form-row > .atk-form-field textarea:not([class*="span"]), .atk-form fieldset .atk-form-row > .atk-form-field select').css({"width":"100%"});
	
});