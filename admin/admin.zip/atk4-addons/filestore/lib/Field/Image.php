<?php
namespace filestore;
class Field_Image extends Field_File {
    public $use_model = 'filestore/Image';
}
