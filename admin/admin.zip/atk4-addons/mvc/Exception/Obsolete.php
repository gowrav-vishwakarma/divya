<?php
/**
 * When some functionality was removed from project
 * 
 * @author Camper (cmd@adevel.com) on 02.07.2009
 */
class Exception_Obsolete extends Exception_InitError{}
